import java.util.Random;
import java.util.Scanner;
import java.text.NumberFormat;
import edu.cwi.parking.ParkingSpot;

public class ParkingFinder {
    public static void main(String[] args) {
        // Variable and Constant Declarations
        long yourSeed;
        int parkingDuration, carX, carY, distance1, distance2, distance3, distance4, closestDistance;
        
        // Class Declaraions
        Scanner keyboard = new Scanner(System.in);
        Random generator;
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        ParkingSpot spot1, spot2, spot3, spot4;

        // Prompt Input
        System.out.println("Enter your random seed:");
        yourSeed = keyboard.nextLong();

        System.out.println("Enter the necessary parking time (minutes):");
        parkingDuration = keyboard.nextInt();

        // Create a random seed from input
        generator = new Random(yourSeed);
        
        // Generate user's car position randomly based on the user's seed
        carX = generator.nextInt(100);
        carY = generator.nextInt(100);

        // Display user's car position on the x and y plane
        System.out.println("The position of your vehicle is:  X: " + carX + " Y: " + carY);


        // Spot One
        spot1 = new ParkingSpot("1st Street", generator.nextInt(100), generator.nextInt(100));

        distance1 = Math.abs(spot1.getLocationX() - carX) + Math.abs(spot1.getLocationY() - carY);

        System.out.println("\nSpot 1: " + spot1 +  
        "\n\tDistance to spot1 is: " + distance1 +
        "\n\tTotal Cost for Spot 1 is: " + (formatter.format(spot1.getCostPerInterval() * Math.ceil((parkingDuration / 10.0)))));

        // Spot Two
        spot2 = new ParkingSpot("2nd Street", generator.nextInt(100), generator.nextInt(100));

        distance2 = Math.abs(spot2.getLocationX() - carX) + Math.abs(spot2.getLocationY() - carY);

        System.out.println("\nSpot 2: " + spot2 +  
        "\n\tDistance to spot2 is: " + distance2 +
        "\n\tTotal Cost for Spot 2 is: " + (formatter.format(spot2.getCostPerInterval() * Math.ceil((parkingDuration / 10.0)))));

        // Spot Three
        spot3 = new ParkingSpot("3rd Street", generator.nextInt(100), generator.nextInt(100));

        spot3.setCostPerInterval(0.3);
        
        distance3 = Math.abs(spot3.getLocationX() - carX) + Math.abs(spot3.getLocationY() - carY);

        System.out.println("\nSpot 3: " + spot3 +  
        "\n\tDistance to spot3 is: " + distance3 +
        "\n\tTotal Cost for Spot 3 is: " + (formatter.format(spot3.getCostPerInterval() * Math.ceil((parkingDuration / 10.0)))));

        // Spot Four
        spot4 = new ParkingSpot("4th Street", generator.nextInt(100), generator.nextInt(100));

        spot4.setCostPerInterval(0.3);
        
        distance4 = Math.abs(spot4.getLocationX() - carX) + Math.abs(spot4.getLocationY() - carY);

        System.out.println("\nSpot 4: " + spot4 +  
        "\n\tDistance to spot4 is: " + distance4 +
        "\n\tTotal Cost for Spot 4 is: " + (formatter.format(spot4.getCostPerInterval() * Math.ceil((parkingDuration / 10.0)))));

        // Find and Display the closest distance without storing data related to the parking spots in variables
        closestDistance = Math.min(Math.min(distance1, distance2), Math.min(distance3, distance4));
        
        System.out.println("\nThe distance to the closest spot is: " + 
        closestDistance);

        // Find and Display the closest parking space
        if (closestDistance == distance1) {
            System.out.println("The closest spot is: " + spot1);

        } else if (closestDistance == distance2) {
            System.out.println("The closest spot is: " + spot2);

        } else if (closestDistance == distance3) {
            System.out.println("The closest spot is: " + spot3);

        } else {
            System.out.println("The closest spot is: " + spot4);

        }

        // Close Scanner
        keyboard.close();
    }
}