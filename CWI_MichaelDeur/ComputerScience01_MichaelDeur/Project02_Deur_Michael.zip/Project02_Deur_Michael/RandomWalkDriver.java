import java.util.Scanner;

public class RandomWalkDriver {
    public static void main(String[] args) {
        int gridSize, seed;
        boolean isGridValid = false, isSeedValid = false;
        RandomWalk walk;
        Scanner keyboard = new Scanner(System.in);

        do {
            System.out.print("Enter grid size: ");
            gridSize = keyboard.nextInt();

            if (gridSize > 0) {
                isGridValid = true;
            } else {
                System.out.println("Error: grid size must be positive!");
            }
        } while (!isGridValid);

        do {
            System.out.print("Enter random seed (0 for no seed): ");
            seed = keyboard.nextInt();

            if (seed >= 0) {
                isSeedValid = true;
            } else {
                System.out.println("Error: random seed must be >= 0!");
            }
        } while (!isSeedValid);  

        if (seed == 0) {
            walk = new RandomWalk(gridSize);
        } else {
            walk = new RandomWalk(gridSize, seed);
        }

        walk.createWalk();
        System.out.println(walk);
    }
}
