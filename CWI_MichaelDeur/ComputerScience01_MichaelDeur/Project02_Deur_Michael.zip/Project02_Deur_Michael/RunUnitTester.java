import edu.cwi.randomwalk.RandomWalkUnitTester;

public class RunUnitTester {
	public static void main(String[] args) {
		RandomWalkUnitTester.main(args);
	}
}
