import java.util.ArrayList;
import java.util.Random;
import java.awt.Point;
import edu.cwi.randomwalk.RandomWalkInterface;

public class RandomWalk implements RandomWalkInterface {
    private int size;
    private boolean done;
    private ArrayList<Point> path;
    private Point start;
    private Point end;
    private Point current;
    private Random generator;

    public RandomWalk(int gridSize) {
        size = gridSize;
        done = false;
        start = new Point(0, gridSize - 1);
        current = new Point(0, gridSize - 1);
        end = new Point(gridSize - 1, 0);
        path = new ArrayList<Point>();
        path.add(current);
        generator = new Random();
    }

    public RandomWalk(int gridSize, long seed) {
        size = gridSize;
        done = false;
        start = new Point(0, gridSize - 1);
        current = new Point(0, gridSize - 1);
        end = new Point(gridSize - 1, 0);
        path = new ArrayList<Point>();
        path.add(current);
        generator = new Random(seed);
    }

    @Override
    public void step() {
        boolean isNorth; // If boolean isNorth if true, moves North / if false, moves East
        Point p1;
        int pointX, pointY;
        pointX = current.x;
        pointY = current.y;

        if(pointX == end.x && pointY == end.y) {
            done = true;
        }

        if (!done) {
            if (pointX >= end.x) {
                pointY--;
                p1 = new Point(pointX, pointY);
                path.add(p1);
                current.y = p1.y;
            } else if (pointY <= end.y) {
                pointX++;
                p1 = new Point(pointX, pointY);
                path.add(p1);
                current.x = p1.x;
            } else {
                isNorth = generator.nextBoolean();
                if(isNorth) {
                    pointY--;
                    p1 = new Point(pointX, pointY);
                    path.add(p1);
                    current = new Point(p1);
                } else {
                    pointX++;
                    p1 = new Point(pointX, pointY);
                    path.add(p1);
                    current = new Point(p1);
                }
            }

            if(pointX == end.x && pointY == end.y) {
                done = true;
            }
        }
    }

    @Override
    public void createWalk() {
        do {
            step();
        } while(!done);
    }


    @Override
    public boolean isDone() {
        return done;
    }

    @Override
    public int getGridSize() {
        return size;
    }

    @Override
    public Point getStartPoint() {
        return start;
    }

    @Override
    public Point getEndPoint() {
        return end;
    }

    @Override
    public Point getCurrentPoint() {
        return current;
    }

    @Override
    public ArrayList<Point> getPath() {
        ArrayList<Point> copyPath = new ArrayList<Point>();
        // As discussed during office hours, these are just several other ways to accomplish cloning.
        // ArrayList<Point> copyPath = new ArrayList<Point>(path);
        // for (int i = 0; i < path.size(); i++) {
        //     copyPath.add(path.get(i));
        // }
        for (Point point : path) {
            copyPath.add(point);
        }
        
        return copyPath;
    }

    public String toString() {
        String result = "";
        for (Point point : path) {
            result += "[" + point.x + ", " + point.y + "] ";
        }

        return result;
    }
}