import edu.cwi.randomwalk.RandomWalkGUI;

public class RunGUITester {
	public static void main(String[] args) {
		RandomWalkGUI.main(args);		
	}

}
