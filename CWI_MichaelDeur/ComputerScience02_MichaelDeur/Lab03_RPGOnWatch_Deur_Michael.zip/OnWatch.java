public interface OnWatch {
	/*
	 * This interface is the observer which is notified when something happens.
	 * The method is technically getting notified when something happens.
	 */
	public void observeEncounter(Encounter encounter);
}