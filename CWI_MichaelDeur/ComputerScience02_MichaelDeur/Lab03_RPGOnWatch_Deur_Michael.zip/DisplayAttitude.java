public interface DisplayAttitude {
	// Interface holding the abstract method for displaying the attitude.
	public void display();
}