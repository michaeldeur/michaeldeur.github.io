public enum Encounter {
	// Enum list of the possible encounters.
	Nothing,
	Squirrel,
	Goblin,
	Troll,
	Dragon
}