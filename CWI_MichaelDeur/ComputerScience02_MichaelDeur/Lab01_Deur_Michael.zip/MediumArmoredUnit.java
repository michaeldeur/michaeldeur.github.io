public abstract class MediumArmoredUnit extends MartialWeaponsBearer {
    /* This abstract class is a child of MartialWeaponsBearer and is a parent of
     * of children who have the characteristic of wearing medium armor.
    */

    /* This constructor allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    protected MediumArmoredUnit(int hitPoints, int armorClass) {
        super(hitPoints, armorClass);
    }

    // This method prints the proper wearArmor statement for wearing medium armor
    public void wearArmor() {
        System.out.println("I wear medium armor!");
    }

    /* This method allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    public String toString() {
        return super.toString();
    }
}
