public abstract class SimpleWeaponsBearer extends Character {
    /* This abstract class is a child of character and is a parent of
     * of children who have the characteristic of bearing simple weapons.
    */

    /* This constructor allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    protected SimpleWeaponsBearer(int hitPoints, int armorClass) {
        super(hitPoints, armorClass);
    }

    // This method prints the proper useWeapons statement for simple weapons.
    public void useWeapon() {
        System.out.println("I kill monsters with simple weapons.");
    }

    /* This method allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    public String toString() {
        return super.toString();
    }
}
