public class Barbarian extends MediumArmoredUnit {
    // Class that allows for Barbarian objects to be created. Child of MediumArmoredUnit.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass
    public Barbarian() {
        super(21, 13);
    }

    // Method that prints out what happens when raging.
    public void tendsToRage() {
        System.out.println("When I get angry, I fight better!");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a barbarian." + super.toString();
    }
}
