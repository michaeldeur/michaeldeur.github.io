public class Cleric extends SimpleWeaponsBearer {
    // Class that allows for Cleric objects to be created. Child of SimpleWeaponsBearer.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass.
    public Cleric() {
        super(14, 17);
    }

    // This method prints the proper wearArmor statement for wearing medium armor.
    public void wearArmor() {
        System.out.println("I wear medium armor!");
    }

    // Method that prints out that the character can cast spells.
    public void castsSpell() {
        System.out.println("My real power is in my spells!");
    }

    // Method that prints out the character's ability to heal others.
    public void healsOthers() {
        System.out.println("My friends rely upon my medical skills.");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a cleric." + super.toString();
    }
}
