public class Ranger extends MediumArmoredUnit {
    // Class that allows for Ranger objects to be created. Child of MediumArmoredUnit.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass
    public Ranger() {
        super(13, 15);
    }

    // Method printing the character's ability to be stealthy.
    public void sneaksAround() {
        System.out.println("I am very sneaky!");
    }

    // Method printing the character's will to survive in harsh enviroments.
    public void willToSurvive() {
        System.out.println("I will survive in the wild!");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a ranger." + super.toString();
    }
}
