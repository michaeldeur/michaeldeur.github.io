public class Rogue extends SimpleWeaponsBearer {
    // Class that allows for Rogue objects to be created. Child of SimpleWeaponsBearer.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass
    public Rogue() {
        super(11, 16);
    }

    // This method prints the proper wearArmor statement for wearing light armor.
    public void wearArmor() {
        System.out.println("I wear light armor!");
    }

    // Method printing the character's ability to be stealthy.
    public void sneaksAround() {
        System.out.println("I am very sneaky!");
    }

    // Method printing the character's ability to pick locks.
    public void picksLock() {
        System.out.println("Picking locks is my specialty!");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a rogue." + super.toString();
    }
}
