public class Adventure {
    /* Author: Michael Deur
     * 
     * This class runs the heirarchy of inheritance classes.
    */
    public static void main(String[] args) {
        // The declaration of each object with an appropiate name
        Knight knight = new Knight();
        Barbarian barbarian = new Barbarian();
        Ranger ranger = new Ranger();
        Rogue rogue = new Rogue();
        Cleric cleric = new Cleric();
        Wizard wizard = new Wizard();

        // Runs the methods of the Knight object
        System.out.println(knight);
        knight.wearArmor();
        knight.useWeapon();
        knight.hasManeuvers();

        // Runs the methods of the Barbarian object
        System.out.println("\n" + barbarian);
        barbarian.wearArmor();
        barbarian.useWeapon();
        barbarian.tendsToRage();

        // Runs the methods of the Ranger object
        System.out.println("\n" + ranger);
        ranger.wearArmor();
        ranger.useWeapon();
        ranger.sneaksAround();
        ranger.willToSurvive();

        // Runs the methods of the Rogue object
        System.out.println("\n" + rogue);
        rogue.wearArmor();
        rogue.useWeapon();
        rogue.sneaksAround();
        rogue.picksLock();

        // Runs the methods of the Cleric object
        System.out.println("\n" + cleric);
        cleric.wearArmor();
        cleric.useWeapon();
        cleric.castsSpell();
        cleric.healsOthers();

        // Runs the methods of the Wizard object
        System.out.println("\n" + wizard);
        wizard.wearArmor();
        wizard.useWeapon();
        wizard.castsSpell();
        wizard.solvesProblems();
    }
}