public abstract class MartialWeaponsBearer extends Character {
    /* This abstract class is a child of character and is a parent of
     * of children who have the characteristic of bearing martial weapons.
    */

    /* This constructor allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    protected MartialWeaponsBearer(int hitPoints, int armorClass) {
        super(hitPoints, armorClass);
    }

    // This method prints the proper useWeapons statement for martial weapons
    public void useWeapon() {
        System.out.println("I wield martial weapons against monsters.");
    }

    /* This method allows for a child super class to be passed through
     * this class to the character class, but keep proper encapsulation.
    */
    public String toString() {
        return super.toString();
    }
}
