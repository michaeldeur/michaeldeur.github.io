public class Knight extends MartialWeaponsBearer {
    // Class that allows for Knight objects to be created. Child of MartialWeaponsBearer.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass.
    public Knight() {
        super(17, 17);
    }

    // This method prints the proper wearArmor statement for wearing heavy armor.
    public void wearArmor() {
        System.out.println("I wear heavy armor!");       
    }

    // Method that prints out the knights ability to have maneuvers.
    public void hasManeuvers() {
        System.out.println("I got some pretty cool fighting moves!");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a knight." + super.toString();
    }
    
}