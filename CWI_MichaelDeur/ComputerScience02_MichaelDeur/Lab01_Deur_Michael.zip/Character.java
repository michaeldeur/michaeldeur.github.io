public abstract class Character {
    /* This abstract class is the top of the heirarchy of the characters.
     * All characters have hitPoints and an armorClass as well as
     * using the wearArmor and useWeapon methods
    */

    // Property for each character's hitPoints.
    private int hitPoints;
    // Property for each character's armorClass.
    private int armorClass;

    /* Constructor that takes in each character's hitPoints and armorClass
     * and places them in the appropiate private properties.
    */
    protected Character(int hitPoints, int armorClass) {
        this.hitPoints = hitPoints;
        this.armorClass = armorClass;
    }

    // Abstract method that is common to each character regarding their armor.
    public abstract void wearArmor();

    // Abstract method that is common to each character regarding their weapon use.
    public abstract void useWeapon();

    /* toString method that uses the private properties to display 
     * the hitPoints and armorClass of the character calling it.
    */
    public String toString() {
        return "\nI have " + hitPoints + " HPs and " + armorClass + " AC";
    }
}
