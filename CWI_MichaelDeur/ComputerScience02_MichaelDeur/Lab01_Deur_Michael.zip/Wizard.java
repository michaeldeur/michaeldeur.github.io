public class Wizard extends Character {
    // Class that allows for Wizard objects to be created. Child of Character.

    // A constructor that gives the parent class the correct values for hitPoints and armorClass
    public Wizard() {
        super(9, 10);
    }

    // This method prints the proper wearArmor statement for wearing no armor.
    public void wearArmor() {
        // This is different from instructions, but was allowed instead of empty.
        System.out.println("I don't need any armor!");
    }

    // This method prints the proper useWeapons statement for a staff.
    public void useWeapon() {
        System.out.println("I can hit monsters with my staff.");
    }

    // Method that prints out that the character can cast spells.
    public void castsSpell() {
        System.out.println("My real power is in my spells!");
    }

    // Method that prints out the character's ability to solve complex problems.
    public void solvesProblems() {
        System.out.println("I am the best problem solver in the party!");
    }

    // Method that prints out the type of character and calls the parent for its toString method.
    public String toString() {
        return "I am a wizard." + super.toString();
    }
}
