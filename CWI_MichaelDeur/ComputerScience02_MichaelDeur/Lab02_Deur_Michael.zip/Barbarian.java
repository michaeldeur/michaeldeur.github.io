public class Barbarian extends Character{
    // Class for the Barbarian and is a child of Character.

    // Constructor that passes the initial hitpoint, armor class, and weapon to the parent class.
    public Barbarian() {
        super(21, 13, new AxeBehavior());
    }

    // toString method that prints out the character's description.
    public String toString() {
        return "Fur-clad Raging Barbarian";
    }
}
