public class SwordBehavior implements WeaponBehavior {
    /* This class is for the behavior of a sword and implements Weapon Behavior.
     * Currently, this class contains a method that print a weapon description to the console.
     */
    public void useWeapon() {
        System.out.println("The sword swishes back and forth to find an opening.");
    }
}
