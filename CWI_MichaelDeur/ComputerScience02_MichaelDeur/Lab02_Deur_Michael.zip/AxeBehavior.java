public class AxeBehavior implements WeaponBehavior {
    /* This class is for the behavior of a axe and implements Weapon Behavior.
     * Currently, this class contains a method that print a weapon description to the console.
     */
    public void useWeapon() {
        System.out.println("The axe cleaves through the air and everything else.");
    }
}
