public class Character {
    /* This class contains generic methods in which child classes who are characters can
     * inherit them to perform tasks and calculate values.
    */

    // These private properties are use to contain the character's current properties
    private int hitPoints;
    private int armorClass;
    private WeaponBehavior weapon;

    /* Protected Constructor that takes in values from children only and initializes them
     * into the class' properties.
     * Note: Although the "this" operator is not required for all items, I think using it on
     * all of them is a good habit to follow as it looks more uniform and can thwart problems
     * caused from changes to the naming of certain variables.
    */ 
    protected Character(int initialHitPoints, int armorClass, WeaponBehavior initialWeapon) {
        this.hitPoints = initialHitPoints;
        this.armorClass = armorClass;
        this.weapon = initialWeapon;        
    }

    /* Service Method that calls the weapon behavior to be used if the character's health is
     * above zero, else it prints that the hero is downed.
    */
    public void fight() {
        if (hitPoints > 0) {
            weapon.useWeapon();
        } else {
            System.out.println("Is down for the count...");
        }
    }

    // Service method that allows other classes to set the weapon behavior.
    public void setWeapon(WeaponBehavior weapon) {
        this.weapon = weapon;
    }

    /* Service method that allows other classes get the current WeaponBehavior.
     * Note: Although this is an object, the lack of copying it does not break
     * encapsulation. I did, however; take the precaution and create a temporary
     * object for it.
     */
    public WeaponBehavior getWeapon() {
        WeaponBehavior tempWeapon = weapon;

        return tempWeapon;

        // return weapon;
    }

    // Service method that allows other classes get the current hitPoints.
    public int getHitPoints() {
        return hitPoints;
    }

    // Service method that allows other classes get the current armorClass.
    public int getArmorClass() {
        return armorClass;
    }

    /* Service method that takes in damage as an int and calculates whether the
     * hero can take damage and survive based on its hitPoints. If the hero can't survive,
     * then its hitPoints are put at zero; else, since the hero can survive or is at exactly
     * zero hitPoints after, the hero takes the damage.
     * Note: Prevents negative hitPoints.
     */
    public void takeDamage(int damage) {
        if ((hitPoints - damage) < 0) {
            hitPoints = 0;
        } else {
            hitPoints -= damage;
        }
    }
}
