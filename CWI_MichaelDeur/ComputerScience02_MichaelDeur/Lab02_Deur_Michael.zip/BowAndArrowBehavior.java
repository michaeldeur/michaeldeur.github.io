public class BowAndArrowBehavior implements WeaponBehavior {
    /* This class is for the behavior of a bow and arrow and implements Weapon Behavior.
     * Currently, this class contains a method that print a weapon description to the console.
     */
    public void useWeapon() {
        System.out.println("The arrow streaks through the air to its target.");
    }
}
