public class MagicStaffBehavior implements WeaponBehavior {
    /* This class is for the behavior of a magic staff and implements Weapon Behavior.
     * Currently, this class contains a method that print a weapon description to the console.
     */
    public void useWeapon() {
        System.out.println("The staff crackles with eldritch power.");
    }
}
