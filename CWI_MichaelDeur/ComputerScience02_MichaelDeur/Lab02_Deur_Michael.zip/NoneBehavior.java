public class NoneBehavior implements WeaponBehavior {
    /* This class is for the behavior of a having no weapon and implements Weapon Behavior.
     * Currently, this class contains a method that print a description what the
     * character would do without a weapon to the console.
     */
    public void useWeapon() {
        System.out.println("Arms flail wildly in an attempt to confuse.");
    }
}
