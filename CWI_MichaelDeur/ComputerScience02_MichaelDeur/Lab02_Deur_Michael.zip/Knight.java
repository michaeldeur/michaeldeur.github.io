public class Knight extends Character {
    // Class for the Knight and is a child of Character.

    // Constructor that passes the initial hitpoint, armor class, and weapon to the parent class.
    public Knight() {
        super(17, 17, new SwordBehavior());
    }

    // toString method that prints out the character's description.
    public String toString() {
        return "Knight in Shining Armor";
    }
}
