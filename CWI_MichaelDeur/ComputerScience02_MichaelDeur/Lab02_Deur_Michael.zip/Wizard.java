public class Wizard extends Character {
    // Class for the Wizard and is a child of Character.

    // Constructor that passes the initial hitpoint, armor class, and weapon to the parent class.
    public Wizard() {
        super(9, 10, new MagicStaffBehavior());
    }

    // toString method that prints out the character's description.
    public String toString() {
        return "Mysterious, Arcane Wizard";
    }
 }
