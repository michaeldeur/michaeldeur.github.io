public class Ranger extends Character {
    // Class for the Ranger and is a child of Character.

    // Constructor that passes the initial hitpoint, armor class, and weapon to the parent class.
    public Ranger() {
        super(13, 15, new BowAndArrowBehavior());
    }

    // toString method that prints out the character's description.
    public String toString() {
        return "Quick, Stealthy Ranger";
    }
}