public class Adventure {
    /* This class runs the rest of the program.
     * Part members are created and character actions are taken and then displayed
    */
    public static void main(String[] args) {
        /* Creates an array of characters filled with each of the four
         * different partymembers.
        */
        Character[] partyMembers = new Character[4];
        partyMembers[0] = new Knight();
        partyMembers[1] = new Barbarian();
        partyMembers[2] = new Ranger();
        partyMembers[3] = new Wizard();

        /* A foreach loop that runs through each partyMember character object
         * in the partyMembers array running the content for each member.
        */
        for (Character partyMember : partyMembers) {
            System.out.println(partyMember);
            /* Note: The reason why the follow line is not accomplished through the Character class is
             * because there is no toString method in the UML Diagiam provided and this seems like the second
             * best pausible way to do this, follow the instructions, and not induce alot of code duplication.
            */
            System.out.println("Hit Points: " + partyMember.getHitPoints() + "\nArmor Class: " + partyMember.getArmorClass());
            partyMember.fight();
            System.out.println();
        }

        // This line announces that a dragon is attacking the partyMembers.
        System.out.println("The Dragon Attacks...");

        // This line adjusts the knight's weapon.
        partyMembers[0].setWeapon(new NoneBehavior());
        // This line deals 100 damage points to the Barbarian.
        partyMembers[1].takeDamage(100);
        // This line deals 50 damage points to the Ranger.
        partyMembers[2].takeDamage(50);

        /* This foreach loop that runs through each partyMember character object
         * in the partyMembers array running the content for each member.
         * Note: Some of the output may be different because of the previous attack.
        */
        for (Character partyMember : partyMembers) {
            System.out.println(partyMember);
            /* Note: The reason why the follow line is not accomplished through the Character class is
             * because there is no toString method in the UML Diagiam provided and this seems like the second
             * best pausible way to do this, follow the instructions, and not induce alot of code duplication.
            */
            System.out.println("Hit Points: " + partyMember.getHitPoints() + "\nArmor Class: " + partyMember.getArmorClass());
            partyMember.fight();
            System.out.println();
        }
    }
}
