public interface WeaponBehavior {
    /* This interface is part of the stategy pattern.
     * This useWeapon abstract method allow the method to be defined by
     * classes that implement it.
     */
    public void useWeapon();
}
