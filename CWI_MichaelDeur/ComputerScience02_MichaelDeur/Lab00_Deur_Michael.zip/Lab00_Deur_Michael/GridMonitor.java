// Author: Michael Deur

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GridMonitor implements GridMonitorInterface { // Determines whether a ship is safe to fly or not based on the values of the cells in the energy grid.
    private int rows; // Declares a property for the table's rows.
    private int columns; // Declares a property for the table's columns.
    private double[][] gridData; // Declares an array for the base data.
    private double[][] getSurroundingSumGrid; // Declares an array for the sums of the adjacent grid positions.
    private double[][] getSurroundingAvgGrid; // Declares an array for the average of the sums of the adjacent grid positions.
    private double[][] deltaGrid; // Declares an array for the 50% of the average of the sums of the adjacent grid positions.
    private boolean[][] dangerGrid; // Declares an array for booleans of whether the base grid values deviate more than 50% from the average of the sums of the adjacent grid postions.
    private String gridString; // Declares a string property used to hold the string describing the safety of the ship.

    public GridMonitor(String fileName) throws FileNotFoundException { // Class' constructor 
        Scanner scan = new Scanner(new File(fileName)); // Scanner, creating a anonymous file object, and taking a txt file name from the constructor.
        rows = scan.nextInt(); // Is a variable int given by the txt file to state how many rows there will be in the grid.
        columns = scan.nextInt(); // Is a variable int given by the txt file to state how many columns there will be in the grid.
        gridData = new double[rows][columns]; // Initializes the size for the array size based on th found grid size.
        getSurroundingSumGrid = new double[rows][columns]; // Initializes the size for the array size based on th found grid size.
        getSurroundingAvgGrid = new double[rows][columns]; // Initializes the size for the array size based on th found grid size.
        deltaGrid = new double[rows][columns]; // Initializes the size for the array size based on th found grid size.
        dangerGrid = new boolean[rows][columns]; // Initializes the size for the array size based on th found grid size.
        baseGridCalculator(scan); // Calls a support method for calculation passing in the scanner.
        sumGridCalculator(); // Calls a support method for calculation.
        avgAndDeltaGridCalculator(); // Calls a support method for calculation.
        dangerGridCalculator(); // Calls a support method for calculation.
        dangerChecker(); // Calls a support method for checking.
        scan.close(); // Closes the scanner to prevent malicious intent.
    }

    private void baseGridCalculator(Scanner scan) { // (Support method) Reads each grid position from the txt file and places it in the appropiate array location.
        for (int i = 0; i < rows; i++) {  // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {

                gridData[i][j] = scan.nextDouble(); // Scans the next double located in the txt file.
            }
        }
    } 

    private void sumGridCalculator() { // (Support method) Fills each grid position with the Sum of the numbers that are surrounding each grid position - top, bottom, left, right; if the position is located at a grid border, itself is then counted in lieu of an adjacent position.
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {

                getSurroundingSumGrid[i][j] = i == 0 ? gridData[i][j] : gridData[i-1][j]; // If top row counts itself else counts top adjacent grid position.
                getSurroundingSumGrid[i][j] += i == (rows - 1) ? gridData[i][j] : gridData[i+1][j]; // If top row counts itself else counts bottom adjacent grid position.
                getSurroundingSumGrid[i][j] += j == 0 ? gridData[i][j] : gridData[i][j-1]; // If top row counts itself else counts left adjacent grid position.
                getSurroundingSumGrid[i][j] += j == (columns - 1) ? gridData[i][j] : gridData[i][j+1]; // If top row counts itself else counts right adjacent grid position.
            }
        }
    }

    private void avgAndDeltaGridCalculator() { // (Support method) Fills two different arrays in which one is being filled with the average of the sums found in  and the other finds how much 50% deviation of average is. 
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {

                getSurroundingAvgGrid[i][j] = getSurroundingSumGrid[i][j]; // Mirrors two arrays.
                getSurroundingAvgGrid[i][j] /= 4; // Finds the average of the sums.

                deltaGrid[i][j] = getSurroundingAvgGrid[i][j]; // Mirrors two arrays.
                deltaGrid[i][j] = Math.abs(deltaGrid[i][j]) / 2; // Finds 50% deviation.
            }
        }
    }

    private void dangerGridCalculator() { // (Support method) Decides whether a particular grid cell position is in danger of exploding.
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {

                dangerGrid[i][j] = (gridData[i][j] > (getSurroundingAvgGrid[i][j] + deltaGrid[i][j]) || 
                gridData[i][j] < (getSurroundingAvgGrid[i][j] - deltaGrid[i][j])); // If the base number is outside the range created by +- deviation from the average, then it returns true else false.
            }
        }
    }

    private void dangerChecker() { // (Support method) Computes whether a particular table is dangerous due to there being a grid position outside the safe range.
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {
                if (dangerGrid[i][j] == true) { // Fills the string depending on the contents of dangerGrid.
                    gridString = "Don't Enter!!! The fuel cells may explode!"; // String saying the ship is unsafe.
                    i = rows; // Used to exit the inner loop.
                    j = columns; // Used to exit the outer loop.
                } else {
                    gridString = "Have a safe flight!"; // String saying the ship is safe.
                }
            }
        }
    }

    private double[][] encapsulationProtector(double[][] someDoubleArray) { // (Support method) Provides proper encapsulation by physically copying every double[][] array entered into it.
        double[][] replacementArray = new double[rows][columns]; // Creates an array that replace the array in the heading and is the exact same size.
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position.
            for (int j = 0; j < columns; j++) {

                replacementArray[i][j] = someDoubleArray[i][j]; // Replaces each grid position in the array with the one primitive datatype located in the other array. 
            }
        }
        return replacementArray; // Returns the copied array.
    }

    public double[][] getBaseGrid() { // (Service method) Calls the encapsulation protector to copy the array.
        double[][] protectedBaseData = encapsulationProtector(gridData); // Creates a new array and calls support method.
        return protectedBaseData; // Returns copied array.
    }

    public double[][] getSurroundingSumGrid() { // (Service method) Calls the encapsulation protector to copy the array.
        double[][] protectedSumData = encapsulationProtector(getSurroundingSumGrid); // Creates a new array and calls support method.
        return protectedSumData; // Returns copied array.
    }

    public double[][] getSurroundingAvgGrid() { // (Service method) Calls the encapsulation protector to copy the array.
        double[][] protectedAvgData = encapsulationProtector(getSurroundingAvgGrid); // Creates a new array and calls support method.
        return protectedAvgData; // Returns copied array.
    }

    public double[][] getDeltaGrid() { // (Service method) Calls the encapsulation protector to copy the array.
        double[][] protectedDeltaData = encapsulationProtector(deltaGrid); // Creates a new array and calls support method.
        return protectedDeltaData; // Returns copied array.
    }

    public boolean[][] getDangerGrid() { // (Service method) Creates a copy of the boolean array inside this method.
        boolean[][] protectedDangerData = new boolean[rows][columns]; // Creates a boolean array an initializes size.
        for (int i = 0; i < rows; i++) { // Double loop that loops through every grid position
            for (int j = 0; j < columns; j++) {
                protectedDangerData[i][j] = dangerGrid[i][j]; // Replaces each grid position in the array with the one primitive datatype located in the other array. 
            }
        }
        return protectedDangerData; // Returns copied array.
    }

    public String toString() { // (Service method) Overrides the Object's toString and returns whether the ship is safe to rid or not.
        return gridString; // Returns a string that informs the user whether the ship is safe to rid or not.
    }
}