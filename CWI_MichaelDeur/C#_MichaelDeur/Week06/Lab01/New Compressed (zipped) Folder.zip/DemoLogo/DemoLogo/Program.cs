﻿//Michael Deur
//September 27, 2023
using System;
using static System.Console;

class DemoLogo
{
    private static void DisplayCompanyLogo()
    {
        WriteLine("See Sharp Optical");
        WriteLine("We prize your eyes");
    }
    static void Main()
    {
        Write("Our company is ");
        DisplayCompanyLogo();

    }
}