﻿//Michael Deur
//August 21, 2023
using System;
class ExercisePg45
{
	static void Main()
	{
        Console.WriteLine("Exercise Pg. 45");
        Console.WriteLine(" ");
        Console.WriteLine("Question Three");
		Console.WriteLine(" ");

        Console.WriteLine("3a: your cousin = myFamily; myRelatives");
		Console.WriteLine("3b: Macys = favoriteRestaurant; localEatery");
		Console.WriteLine("3c: Egypt = foreignCountry; biblicalCountry");
		Console.WriteLine("3d: Thomas Jefferson = usPresident; foundingFather");

        Console.WriteLine(" ");
        Console.WriteLine("Question Four - PersonalInfo");
		Console.WriteLine(" ");

        Console.WriteLine("Personal Name: John Doe");
	    Console.WriteLine("Birthdate: January 1, 2000");
		Console.WriteLine("Work Phone Number: (208) 797-4245");
		Console.WriteLine("Cell Phone Number: (208) 324-6594");

        Console.WriteLine(" ");
        Console.WriteLine("Question Five - Lyrics");
        Console.WriteLine(" ");

        Console.WriteLine("I can only imagine");
		Console.WriteLine("What it will be like");
		Console.WriteLine("When I walk by Your side");
		Console.WriteLine("I can only imagine");

        Console.WriteLine(" ");
        Console.WriteLine("Question Six - Comments");
        Console.WriteLine(" ");

        /*This is a block comment.
        It used for multi-line comments*/
        //This is a line comment. It is used for single line comments

        Console.WriteLine("/*This is a block comment. It used for multi-line comments*/");
		Console.WriteLine("//This is a line comment. It is used for single line comments");

        Console.WriteLine(" ");
        Console.WriteLine("Question Seven - Stop Sign");
        Console.WriteLine(" ");

        Console.WriteLine("   XXXXXX   ");
		Console.WriteLine(" X        X ");
		Console.WriteLine("X   STOP   X");
		Console.WriteLine(" X        X ");
		Console.WriteLine("   XXXXXX   ");
		Console.WriteLine("      X     ");
		Console.WriteLine("      X     ");
		Console.WriteLine("      X     ");
		Console.WriteLine("      X     ");

        Console.WriteLine(" ");
        Console.WriteLine("Question Eight - Big Letter");
        Console.WriteLine(" ");

        Console.WriteLine("M           M");
		Console.WriteLine("M M       M M");
		Console.WriteLine("M   M   M   M");
		Console.WriteLine("M     M     M");
		Console.WriteLine("M           M");
		Console.WriteLine("M           M");
		Console.WriteLine("M           M");
		Console.WriteLine("M           M");
	}
}